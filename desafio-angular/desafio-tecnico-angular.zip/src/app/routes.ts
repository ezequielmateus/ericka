import { Routes } from "@angular/router";
import { AppComponent } from "./app.component";
import { CharactersComponent } from "./components/characters/characters.component";
import { ComicsComponent } from "./components/comics/comics.component";


export const routes: Routes = [
    {
        path: 'comics',
        component: ComicsComponent
    },
    {
        path: 'characters',
        component: CharactersComponent
    }
]