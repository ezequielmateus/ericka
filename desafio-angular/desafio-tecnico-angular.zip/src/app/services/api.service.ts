import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Md5 } from 'ts-md5/dist/md5';

@Injectable({ providedIn: 'root' })
export class ApiService {

  ts = new Date().getUTCMilliseconds().toString();
  publicKey = "1f002c530c394cb26977488934e941b0";
  privateKey = "f17af4ed54c7f2767dd72381374b09448a970951";
  hash = Md5.hashStr(this.ts + this.privateKey + this.publicKey).toString();

  params = {
    ts: this.ts,
    hash: this.hash,
    apikey: this.publicKey
  }

  constructor(private httpClient: HttpClient) { }

  getComics(): Observable<any> {

    return this.httpClient.get(
      'http://gateway.marvel.com/v1/public/comics',
      {
        params: this.params
      }
    )
  }

  getCharacters(): Observable<any> {
    return this.httpClient.get(
      'http://gateway.marvel.com/v1/public/characters',
      {
        params: this.params
      }
    )
  }

}