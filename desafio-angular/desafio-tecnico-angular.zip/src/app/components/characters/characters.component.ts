import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/services/api.service';

interface ICharacter {
  id: number;
  name: string;
  description: string;
  thumbnail: {
    path: string;
    extension: string;
  };
  comics: {
    available: number;
    items: [
      {
        resourceURI: string;
        name: string;
      }
    ]
  };
}

@Component({
  selector: 'app-characters',
  templateUrl: './characters.component.html',
  styleUrls: ['./characters.component.css']
})
export class CharactersComponent implements OnInit {

  characters: ICharacter[] = [];

  listMode: boolean = false;

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.apiService.getCharacters().subscribe((r) => {
      const results = r.data.results;
      this.characters = results;
    })
  }

}
